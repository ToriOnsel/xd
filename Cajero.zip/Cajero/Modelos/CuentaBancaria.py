class CuentaBancaria:
    numero=""
    cliente=""
    dni=""
    monto=""
    itf=""#descuentos al 10% de la cantidad a retirar
#********************#

    def __init__(self,cliente,dni):
        self.monto=0
        self.cliente=cliente
        self.dni=dni

#********************#
    def depositar(self,monto):
        self.monto=self.monto+monto

    def retirar(self,cantidad):
        saldo=0
        self.itf=(cantidad*0.10)
        if((cantidad+self.itf)<=self.monto):
            saldo=self.monto-cantidad
            self.monto=do
        else:
            saldo=-1
        return saldo

    def estadoCuenta(self):
        datos=[self.dni,self.cliente,self.monto]
        return datos

#Metodos Set y Metodos Get
    def setCliente(self,cliente):
        self.cliente=cliente
    def getCliente(self):
        return self.cliente

    def setDni(self,dni):
        self.dni=dni
    def getDni(self):
        return self.dni

    def setMonto(self,monto):
        self.monto=monto
    def getMonto(self):
        return self.monto