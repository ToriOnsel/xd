class Persona:

    def __init__(self,nombre,apellido,dni,direccion,telefono):
        self.nombre=nombre
        self.apellido=apellido
        self.dni=dni
        self.direccion=direccion
        self.telefono=telefono

#Metodos Set y Metodos Get
    def setNombre(self,nombre):
        self.nombre=nombre
    def getNombre(self):
        return self.nombre


    def setApellido(self,apellido):#Bucle 1
        self.apellido=apellido
    def getApellido(self):
        return self.apellido#Bucle 2


    def setDni(self,dni):
        self.dni=dni
    def getDni(self):
        return self.dni


    def setDireccion(self,direccion):
        self.direccion=direccion
    def getDireccion(self):
        return self.direccion


    def setTelefono(self,telefono):
        self.telefono=telefono
    def getTelefono(self):
        return self.telefono