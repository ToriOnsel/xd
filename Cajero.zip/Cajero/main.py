from Modelos.Persona import Persona
from Modelos.CuentaBancaria import CuentaBancaria

#Crear Un Objeto Persona
obj=Persona("Juan","Perez","12345667","Jr Calleria #123","961909432")

#Abrir Una Cuenta
C1=CuentaBancaria(obj.getNombre()+" "+obj.getApellido(),obj.getDni())

#Mostrar El Estado De Cuenta
valores=C1.estadoCuenta()
print("Dni: ",valores[0])
print("Cliente ",valores[1])
print("Monto: ",valores[2])
print("*************************")
#Realizar Deposito
C1.depositar(1000)

#Mostar El Estado De Cuenta
valores=C1.estadoCuenta()
print("Dni: ",valores[0])
print("Cliente ",valores[1])
print("Monto: ",valores[2])
print("*************************")

#Realizar Retiro (Se puede hacer input)
respuesta=C1.retirar(200)
if (respuesta!=-1):
    print("Retiro Correcto")
else:
    print("No se puede retirar")
print("*************************")

#Mostar El Estado De Cuenta
valores=C1.estadoCuenta()
print("Dni: ",valores[0])
print("Cliente ",valores[1])
print("Monto: ",valores[2])
print("*************************")

