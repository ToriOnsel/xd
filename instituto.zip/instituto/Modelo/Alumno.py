from Modelo.Persona import persona
#creamos la clase hijo que hereda de la clase persona

class Alumno(persona):
    codigo=""
    carrera=""
    turno=""


    def matricula(self,codigo,carrera,turno):
        self.codigo=codigo
        self.carrera=carrera
        self.turno=turno

    def setcodigo(self,codigo):
        self.codigo=codigo
    def getcodigo(self):
        return self.codigo

    def setcarrera(self,carrera):
        self.carrera=carrera
    def getcarrera(self):
        return self.carrera

    def setturno(self,turno):
        self.turno=turno
    def getturno(self):
        return self.turno
