
class Aula():

    def __init__(self,id,piso,pabellon,especialidad):
        self.id=id
        self.piso=piso
        self.pabellon=pabellon
        self.especialidad=especialidad

    def setid(self,id):
        self.id=id
    def getid(self):
        return self.id

    def setpiso(self,piso):
        self.piso=piso
    def getpiso(self):
        return self.piso

    def setpabellon(self,pabellon):
        self.pabellon=pabellon
    def getpabellon(self):
        return self.pabellon

    def setespecialidad(self,especialidad):
        self.especialidad=especialidad
    def getespecialidad(self):
        return self.especialidad

