from Modelo.Alumno import Alumno
from Modelo.Profesor import profesor
from Modelo.Aula import Aula


#crear 5 alumnos
a1=Alumno("juam","dias","565622","jr atahualpa","2516546546","19","masculino")
a2=Alumno("rosame","melano","5654542","jr lima","251555546","18","femenino")
a3=Alumno("devora","meltroso","564545642","jr at","25154654","19","femenino")
a4=Alumno("trabujo","del pernanbuco","564545","jr atpa","2543136","20","masculino")
a5=Alumno("isek","kkseca","561132","jr lima","254545466","19","masculino")

#matricular 5 alumnos
a1.matricula("10","sofware","mañana")
a2.matricula("5","administracion","mañana")
a3.matricula("6","sistemas","tarde")
a4.matricula("9","algoritmos","tarde")
a5.matricula("12","sofware","noche")
###########################################################

l1=profesor("luis","ivan","5662","jr lima","454566565","45","masculino")
l2=profesor("luca","gor","5562","jr lama","454555455","50","masculino")
l3=profesor("marco","ian","511545","jr lima","4545465","55","masculino")
l4=profesor("luisa","karina","54562","jr pucallpa","45400065","35","femenino")

l1.setmaestria("desarrollador")
l2.setmaestria("matematica")
l3.setmaestria("desiñador grafico profecional")
l4.setmaestria("desarrollador")


ll1=Aula("1","1","a","matematicas")
ll2=Aula("2","2","a1","adminisracion")
ll3=Aula("3","1","aa","diseño grafico")
ll4=Aula("4","2","a2","software")
#almacenar los alumnos
lista=[]
lista.append(a1)
lista.append(a2)
lista.append(a3)
lista.append(a4)
lista.append(a5)

lista1=[]
lista1.append(l1)
lista1.append(l2)
lista1.append(l3)
lista1.append(l4)

lista3=[]
lista3.append(ll1)
lista3.append(ll2)
lista3.append(ll3)
lista3.append(ll4)
#cantida de matriculados

#operaciones
print("num matriculado: ",len(lista))

#cantida de honbre matriculados
cant=0
for i in range(0,len(lista)):
    obj=lista[i]#sacar el objetode la lista
    if(obj.getsexo()=="masculino"):
        cant=cant+1
        #incrementar
    else:
        pass
print("Cantidad hombre: ",cant)
#cuantos alumnos estan en el turno
cant1=0
for i in range(0,len(lista)):
    obj1=lista[i]
    if(obj1.getturno()=="noche"):
        cant1=cant1+1
    else:
        pass
print("Cantidad por turno noche: ",cant1)
#cuantos alumnos menores de edad##########
cant2=0
for i in range(0,len(lista)):
    obj2=lista[i]
    if(obj2.getedad()>"18"):
        cant2=cant2+1
    else:
        pass
print("mayores de edad :",cant2)

#dando codigo iD a quien pertenese############
id="12"
for i in range(0,len(lista)):
    obj=lista[i]
    if(id==obj.getcodigo()):
        print("----------------------------")
        print("alumno :",obj.getNombre()+""+obj.getapellido())
        print("especialidad :",obj.getcarrera())
        print("turno: ",obj.getturno())
        print("--------------------------------------")
    else:
        pass
#crear 4 objetos y 4 aulas y realizar los siguientes operaciones
#cuantos docentes enseñan en el curso de matematica?
cant3=0
for i in range(0,len(lista1)):
    obj4=lista1[i]
    if(obj4.getmaestria()=="matematica"):
        cant3=cant3+1
    else:
        pass
print("los docentes que enseñan matematicas son :",cant3)

#cuantos aulas estan destinadas a la carrera de administracion?
cant4=0
for i in range(0,len(lista3)):
    obj5=lista3[i]
    if(obj5.getespecialidad()=="administracion"):
        cant4=cant4+1
    else:
        pass
print("aulas destinadas a adminstracion; ",cant4)

#¿cuantos docentes son mujeres?
cant5=0
for i in range(0,len(lista1)):
    obj6=lista1[i]
    if(obj6.getsexo()=="femenino"):
        cant5=cant5+1
    else:
        pass
print("cantidad de docentes que son mujeres: ",cant5)

#ingresar el codigo de aula y reporte todos sus datos del aula.
id1=str(input("ingrese id : "))
for i in range(0,len(lista3)):
    obj7=lista3[i]
    if(id1==obj7.getid()):
        print("----------------------------")
        print("id del aula :",obj7.getid()+"  piso :"+obj7.getpiso())
        print("pabellon :",obj7.getpabellon())
        print("especialidad asignada al aula: ",obj7.getespecialidad())
        print("--------------------------------------")
    else:
        pass
