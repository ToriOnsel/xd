from Modelos.Alumno import Alumno
from Modelos.Profesor import profesor
from Modelos.Aula import Aula


#crear 5 alumnos

a1=Alumno("Zoyca","Brazos","565622","jr Calleria #345","12345678","19","M")
a2=Alumno("Elva","Ginon","5654542","jr lima #432","251555546","18","F")
a3=Alumno("devora","meltroso","564545642","jr S/n #431","25154654","19","F")
a4=Alumno("Ernes","Tose","564545","jr Tapera #412","2543136","20","M")
a5=Alumno("Jimmy","Nuto","561132","jr Lima #243","254545466","19","M")

#Matricular 5 alumnos
a1.matricula("11","Software","Mañana")
a2.matricula("12","Mecanica","Mañana")
a3.matricula("13","Administracion","Tarde")
a4.matricula("14","Diseño Grafico","Tarde")
a5.matricula("15","Contabilidad","Noche")
###########################################################

l1=profesor("Erick","Abrazo","5662","jr Calleria #321","454566565","45","M")
l2=profesor("Lucas","Sosa","5562","jr Ucayali #123","454555455","50","M")
l3=profesor("Luisa","Naso","511545","jr Vergazus #101","4545465","55","F")
l4=profesor("luisa","karina","54562","jr Neperdonas #102","45400065","35","F")

l1.setmaestria("Administracion")
l2.setmaestria("Contabilidad")
l3.setmaestria("Diseño Grafico")
l4.setmaestria("Mecanica")

#Crear 4 objetos y 4 aulas y realizar los siguientes operaciones
ll1=Aula("1","4","a","Contabilidad")
ll2=Aula("2","3","b","Adminisracion")
ll3=Aula("3","2","c","Diseño Grafico")
ll4=Aula("4","1","d","Mecanica")

#Almacenar los alumnos
lista=[]
lista.append(a1)
lista.append(a2)
lista.append(a3)
lista.append(a4)
lista.append(a5)

#Almacenar los alumnos
lista1=[]
lista1.append(l1)
lista1.append(l2)
lista1.append(l3)
lista1.append(l4)

#Almacenar los alumnos
lista3=[]
lista3.append(ll1)
lista3.append(ll2)
lista3.append(ll3)
lista3.append(ll4)
#Cantida de matriculados

#operaciones
print("**********************************")
print("Numª de Matriculado: ",len(lista))

#Cantidad de Hombres matriculados
cant_M=0
for i in range(0,len(lista)):
    obj=lista[i]#sacar el objetode la lista
    if(obj.getsexo()=="M"):
        cant_M=cant_M+1
        #incrementar
    else:
        pass
print("Cantidad de Hombres: ",cant_M)
#cuantos alumnos estan en el turno


#Cantidad de Mujeres matriculados
cant_F=0
for i in range(0,len(lista)):
    obj=lista[i]#sacar el objetode la lista
    if(obj.getsexo()=="F"):
        cant_F=cant_F+1
        #incrementar
    else:
        pass
print("Cantidad de Mujeres: ",cant_F)

#Cantidad DE Personas Que Estudian En Determinado Tiempo
#Cuantos alumnos hay en los turnos
print("**********************************")
cant1=0
turno=str(input("Ingrese el Turno(Mañana;Tarde;Noche)-> "))
for i in range(0,len(lista)):
    obj1=lista[i]
    if(obj1.getturno()==str(turno)):
        cant1=cant1+1
    else:
        pass
print("Hay ",cant1,"alumno(os) del turno "+str(turno))
print("**********************************")

#¿Cuantos alumnos son menores de edad?
cant2=0
for i in range(0,len(lista)):
    obj2=lista[i]
    if(obj2.getedad()>"18"):
        cant2=cant2+1
    else:
        pass
print("Hay ",cant2," Mayores de edad")
print("**********************************")

#Buscando el Id del alumno
id=str(input("Ingrese al alumno su ID(11-15)-> "))
for i in range(0,len(lista)):
    obj=lista[i]
    if(id==obj.getcodigo()):
        print("**********************************")
        print("Alumno: ",obj.getNombre()+" "+obj.getapellido())
        print("Especialidad: ",obj.getcarrera())
        print("Turno: ",obj.getturno())
        print("**********************************")
    else:
        pass

#cuantos docentes enseñan en el curso de matematica?
cant3=0
maestro=str(input("¿Que enseña el docente?-> "))
for i in range(0,len(lista1)):
    obj4=lista1[i]
    if(obj4.getmaestria()=="Mecanica"):
        cant3=cant3+1
    else:
        pass
print("Los docentes que enseñan "+str(maestro)," son: ",cant3)
print("**********************************")

#¿Cuantos aulas estan destinadas a su carrera?
cant4=0
carrera=str(input("Ingrese la carrera destinada a sus aulas:"))
for i in range(0,len(lista3)):
    obj5=lista3[i]
    if(obj5.getespecialidad()==carrera):
        cant4=cant4+1
    else:
        pass
print("Las aulas destinadas a ",carrera," son: ",cant4)


#¿Cuantos docentes son mujeres?
cant5_F=0
for i in range(0,len(lista1)):
    obj6=lista1[i]
    if(obj6.getsexo()=="F"):
        cant5_F=cant5_F+1
    else:
        pass
print("**********************************")
print("Cantidad de docentes que son Mujeres: ",cant5_F)

#¿Cuantos docentes son Hombres?
cant5_M=0
for i in range(0,len(lista1)):
    obj6=lista1[i]
    if(obj6.getsexo()=="M"):
        cant5_M=cant5_M+1
    else:
        pass
print("Cantidad de docentes que son Hombres: ",cant5_M)


#Ingresar el codigo de aula y reporte todos sus datos del aula.
print("**********************************")
id1=str(input("Ingrese el id(1-5) : "))
for i in range(0,len(lista3)):
    obj7=lista3[i]
    if(id1==obj7.getid()):
        print("**********************************")
        print("Id del aula: ",obj7.getid()+"  Piso: "+obj7.getpiso())
        print("Pabellon: ",obj7.getpabellon())
        print("Especialidad asignada al aula: ",obj7.getespecialidad())
        print("**********************************")
    else:
        pass
