from Modelos.Persona import persona

class profesor(persona):
    maestria=""
    def tutor(self,maestria):
        self.maestria=maestria

    def setmaestria(self,maestria):
        self.maestria=maestria
    def getmaestria(self):
        return self.maestria


