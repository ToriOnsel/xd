class persona:

    def __init__(self,nombre,apellido,dni,direccion,telefono,edad,sexo):
        self.nombre=nombre
        self.apellido=apellido
        self.dni=dni
        self.direccion=direccion
        self.telefono=telefono
        self.edad=edad
        self.sexo=sexo

#metodo set y metodos get
    def setNombre(self,nombre):
         self.nombre=nombre
    def getNombre(self):
        return self.nombre

    def setapellido(self,apellido):
         self.apellido=apellido
    def getapellido(self):
        return self.apellido


    def setdni(self,dni):
         self.dni=dni
    def getdni(self):
        return self.dni

    def setdireccion(self,direccion):
         self.direccion=direccion
    def getdireccion(self):
        return self.direccion

    def settelefono(self,telefono):
        self.telefono=telefono
    def gettelefono(self):
        return self.telefono

    def setedad(self,edad):
        self.edad=edad
    def getedad(self):
        return self.edad

    def setsexo(self,sexo):
        self.sexo=sexo
    def getsexo(self):
        return self.sexo
